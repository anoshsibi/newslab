document.addEventListener('DOMContentLoaded', () => {
    const githubJsonUrl = 'https://raw.githubusercontent.com/anoshsibi/newslab/main/data.json';
    let newsData = [];
    let filteredNews = [];
    let currentPage = 1;
    const newsPerPage = 2;

    // Fetch news data from GitHub
    async function fetchNews() {
        try {
            const response = await fetch(githubJsonUrl);
            const data = await response.json();
            newsData = data.articles;
            filteredNews = newsData;
            displayNews();
            updatePagination();
        } catch (error) {
            console.error('Error fetching news:', error);
        }
    }

    // Display news on the page
    function displayNews() {
        const newsList = document.getElementById('news-list');
        newsList.innerHTML = '';
        const start = (currentPage - 1) * newsPerPage;
        const end = start + newsPerPage;
        const newsToDisplay = filteredNews.slice(start, end);

        newsToDisplay.forEach(news => {
            const newsItem = document.createElement('div');
            newsItem.className = 'news-item';
            newsItem.innerHTML = `
                <h3>${news.title}</h3>
                <img src="${news.urlToImage}" alt="${news.title}" style="width:100%; height:auto;">
                <p>${news.description}</p>
                <a href="${news.url}" target="_blank">Read more</a>
            `;
            newsList.appendChild(newsItem);
        });

        // Update pagination buttons state
        const totalPages = Math.ceil(filteredNews.length / newsPerPage);
        document.getElementById('prev-btn').disabled = currentPage === 1;
        document.getElementById('next-btn').disabled = currentPage === totalPages;
    }

    // Update pagination display
    function updatePagination() {
        const pageNumbers = document.getElementById('page-numbers');
        pageNumbers.innerHTML = '';
        const totalPages = Math.ceil(filteredNews.length / newsPerPage);

        for (let i = 1; i <= totalPages; i++) {
            const pageButton = document.createElement('a');
            pageButton.href = '#';
            pageButton.textContent = i;
            if (i === currentPage) {
                pageButton.classList.add('active');
            }
            pageButton.addEventListener('click', (e) => {
                e.preventDefault();
                currentPage = i;
                displayNews();
                updatePagination();
            });
            pageNumbers.appendChild(pageButton);
        }
    }

    // Handle pagination
    document.getElementById('prev-btn').addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            displayNews();
            updatePagination();
        }
    });

    document.getElementById('next-btn').addEventListener('click', () => {
        const totalPages = Math.ceil(filteredNews.length / newsPerPage);
        if (currentPage < totalPages) {
            currentPage++;
            displayNews();
            updatePagination();
        }
    });

    // Handle search filter
    document.getElementById('search-bar').addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        filteredNews = newsData.filter(news => 
            news.title.toLowerCase().includes(query) || 
            news.description.toLowerCase().includes(query)
        );
        currentPage = 1; // Reset to the first page
        displayNews();
        updatePagination();
    });

    // Handle sorting
    document.getElementById('sort-select').addEventListener('change', (e) => {
        const sortOption = e.target.value;
        if (sortOption === 'date') {
            filteredNews.sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt));
        } else if (sortOption === 'title') {
            filteredNews.sort((a, b) => a.title.localeCompare(b.title));
        }
        currentPage = 1; // Reset to the first page
        displayNews();
        updatePagination();
    });

    // Initial fetch
    fetchNews();
});
